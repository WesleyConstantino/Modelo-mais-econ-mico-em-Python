public class Principal{
  public static void main(String[] args) {
      Motocicleta m1 = new Motocicleta();
      m1.mostraDados();
      Motocicleta m2 = new Motocicleta(1234566,"EMR4965");
      m2.mostraDados();
      Motocicleta m3 = new Motocicleta("Kawasaki","KLX 450R");
      m3.mostraDados();
  }
}