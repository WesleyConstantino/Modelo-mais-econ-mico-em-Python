model=[]
def entrada_carro():
   print(f"digite o modelo do carro:")
   for i in range(4):
    modelo=(input())
   model.append(modelo)

consumo=[]
def entrada_consumo():
   print(f"digite o consumo do carro:")
   for i in range(4):
     con=float(input())
     consumo.append(con)

def economico():
  valor=min(consumo)
  posicao=consumo.index(valor)
  return model[posicao]
    
def main():
  entrada_carro()
  entrada_consumo()
  print (economico())
main()